# Apollo-Health-Care-Hospital
This project presents a comprehensive data analytics solution for Apollo Health Care Hospital using Excel, SQL, and Power BI. The goal is to transform raw hospital data into clear, actionable insights that support better operational decisions. The dashboard highlights key metrics such as patient admissions, department performance, revenue.
